sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("riskmanagementapp.rmrisks.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);